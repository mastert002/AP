define([], function() {
  return {
    "Title": "PlaceHoldersApplicationCustomizer"
  }
});