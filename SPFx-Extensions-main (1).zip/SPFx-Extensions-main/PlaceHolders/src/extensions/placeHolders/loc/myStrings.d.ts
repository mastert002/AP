declare interface IPlaceHoldersApplicationCustomizerStrings {
  Title: string;
}

declare module 'PlaceHoldersApplicationCustomizerStrings' {
  const strings: IPlaceHoldersApplicationCustomizerStrings;
  export = strings;
}
