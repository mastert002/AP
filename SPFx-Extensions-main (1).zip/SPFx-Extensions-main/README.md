# SPFx-Extensions

Source code to support videos at https://youtube.com/c/RobertsDevTalk

also includes packages for desployment

find the package on the sharepoint folder of each solution

e.g. SPFx-Extensions/appBar Hide/sharepoint/solution/ 

in Admin, go to the app catalog and drag in and deploy

the appbar package is configured to hide the app bar by default, but it can be configured in the app catalog for any element id
