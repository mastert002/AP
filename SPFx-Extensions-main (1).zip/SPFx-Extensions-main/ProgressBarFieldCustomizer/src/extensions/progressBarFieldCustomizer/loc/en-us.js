define([], function() {
  return {
    "Title": "ProgressBarFieldCustomizerFieldCustomizer"
  }
});