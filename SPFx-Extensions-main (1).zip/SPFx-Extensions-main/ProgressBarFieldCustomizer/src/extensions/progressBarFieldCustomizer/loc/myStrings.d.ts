declare interface IProgressBarFieldCustomizerFieldCustomizerStrings {
  Title: string;
}

declare module 'ProgressBarFieldCustomizerFieldCustomizerStrings' {
  const strings: IProgressBarFieldCustomizerFieldCustomizerStrings;
  export = strings;
}
