declare interface IAppBarHideApplicationCustomizerStrings {
  Title: string;
}

declare module 'AppBarHideApplicationCustomizerStrings' {
  const strings: IAppBarHideApplicationCustomizerStrings;
  export = strings;
}
