define([], function() {
  return {
    "Title": "AppBarHideApplicationCustomizer"
  }
});