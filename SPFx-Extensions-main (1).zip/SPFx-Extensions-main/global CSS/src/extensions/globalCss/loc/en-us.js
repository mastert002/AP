define([], function() {
  return {
    "Title": "GlobalCssApplicationCustomizer"
  }
});