declare interface IGlobalCssApplicationCustomizerStrings {
  Title: string;
}

declare module 'GlobalCssApplicationCustomizerStrings' {
  const strings: IGlobalCssApplicationCustomizerStrings;
  export = strings;
}
